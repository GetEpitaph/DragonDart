// Мобильное меню
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

// Текущий год в подвале
document.getElementById('year').textContent = new Date().getFullYear();

// Лёгкий эффект падающего снега
const canvas = document.getElementById('snow');
const ctx = canvas.getContext('2d');
let flakes = [];
let width = 0, height = 0;
function resizeSnow() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  width = window.innerWidth; height = window.innerHeight;
  canvas.width = width * dpr; canvas.height = height * dpr;
  canvas.style.width = width + 'px'; canvas.style.height = height + 'px';
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  flakes = Array.from({length: Math.min(90, Math.floor(width / 13))}, () => ({
    x: Math.random() * width, y: Math.random() * height,
    r: Math.random() * 2 + .5, speed: Math.random() * .8 + .25,
    drift: Math.random() * .5 - .25, alpha: Math.random() * .55 + .2
  }));
}
function drawSnow() {
  ctx.clearRect(0, 0, width, height);
  for (const f of flakes) {
    ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(220,245,255,${f.alpha})`; ctx.fill();
    f.y += f.speed; f.x += f.drift;
    if (f.y > height + 5) { f.y = -5; f.x = Math.random() * width; }
    if (f.x > width + 5) f.x = -5;
    if (f.x < -5) f.x = width + 5;
  }
  requestAnimationFrame(drawSnow);
}
if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  resizeSnow(); drawSnow(); window.addEventListener('resize', resizeSnow);
} else {
  canvas.style.display = 'none';
}
